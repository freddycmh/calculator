import "./App.css";
import CostCalculator from "./Components/CostCalculator";

function App() {
  return (
    <>
      <CostCalculator />
    </>
  );
}

export default App;
