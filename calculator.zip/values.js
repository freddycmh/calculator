const values = {};

values.baseURL = "http://localhost:3000";

export default values;
